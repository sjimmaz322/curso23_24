<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4</title>
</head>

<body>
    <?php
    echo "<h2>Ejercicio 4</h2>";
    echo "<p>Crea un array e introduce los siguientes valores: Pedro, Ana, 34 y 1, respectivamente, sin asignar el indice de la matriz.
    Muestra el esquema del array con print_r()</p>";
    $array = array('Pedro', 'Ana', 34, 1);
    print_r($array);
    ?>
</body>

</html>